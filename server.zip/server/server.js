
require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const MongoStore = require("connect-mongo").default || require("connect-mongo");
const bcrypt = require("bcryptjs");
const cors = require("cors");

const app = express();

app.use(cors({
    origin: process.env.CLIENT_URL,
    credentials: true,
}));

app.use(express.json());

app.use(session({
    name: "todo.sid",
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
        mongoUrl: process.env.MONGO_URI,
    }),
    cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: false, // eth https use akkumbo true akkaneii 
        maxAge: 7*24*60*60*1000,
    },

}));

const User = mongoose.model("User", new mongoose.Schema({
    name: String,
    email: {type: String, unique: true},
    password: String,


}));

const Task = mongoose.model("Task", new mongoose.Schema({
    userId:{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        red: "User",
    },
    title:{type: String, required: true},
    completed: {type: Boolean, default: false },
}));

function auth(req, res, next){
    if(!req.session.userId){
        return res.status(401).json({ message: "Please log in"});
    }
    next();

}

app.post("/api/register", async (req, res) => {
    try{
        const {name, email, password } = req.body;
        if (!name?.trim() || !email?.trim() || !password || password.length <8){
            return res.status(400).json({
                message: "Enter your details and a password of 8+ charactors a humple request from rockstar hehe",
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        if(await User.findOne({ email: normalizedEmail})){
            return res.status(409).json({
                message: "email already registered",
            });
        }

        const user = await User.create({
            name: name.trim(),
            email: normalizedEmail,
            password: await  bcrtpt.hash(password, 12),

        });

        req.session.userId = user._id.toString();
        res.status(201).json({name: user.name});

    } 
    catch (err){
        if(err.code === 11000){
         return res.status(409).json({message: "Email already registered"});

        }
        res.status(500).json({ message: "Registration faild"});
    }
});

app.post("/api/login", async  (req, res) => {
    const email = req.body.email?.trim().toLowerCase();
    const user = await User.findOne({ email});
    if(!user || !(await bcrypt.compare(
        req.body.password || "", user.password
    ))){
        return res.status(401).json({
            message: "Invalid email or password",
        });
    }

    req.session.userId = user._id.toString();
    res.json({ name: user.name});

});

app.get("/api/me", auth, async (req, res) =>{
    const user = await User.findById(req.session.userId)
    .select("name email!");

    if(!user){
        return res.status(401).json({ message: "Please login in"});

    }

    res.json(user);
});

app.post("/api/logout", auth, (req, res, next) =>{
    req.session.destroy((err) => {
        if (err) return next(err);

        res.clearCookie("todo.sid");
        res.json({message: "Logged out"});

    });
});

app.get("/api/tasks", auth, async (req, res) => {
    const taks = await Task.find({ userId: req.session.userId})
    .sortI({ _id: -1});
    res.json(tasks);
});

app.post("api/tasks", auth, async (req, res) =>{
    const title = req.body.title?.trim();
    if(!title || title.length > 200) {
        return res.status(400).json({message: "Enter a valid task!"});

    }

    const task = await Task.create({
        userId: req.session.userId,
        title,  
    });

});

app.patch("/api/tasks/:id", auth, async (req, res) =>{
    const task = await Task.findOne({
        _id: req.params.id,
        userId: req.session.userId,

    });

    if (!task){
        return res.status(404).json({message: "Task not found!"});

    }

    if (typeof req.body.completed !== "boolean") {
        return res.status(400).json({message: "Invalid completion status!"});

    }

    task.completed = req.body.completed;
    await task.save();

    res.json(task);

});

app.delete("api/tasks/:id", auth, async (req, res ) =>{
    const task = Task.findOneAndDelete({
        _id: req.params.id,
        userId: req.session.userId,
    });

    if(!task){
        return res.status(404).json({message: "Task not found"});
    }

    res.json({message: "Task deleted! by Y0U!"});
});

mongoose.connect(process.env.MONGO_URI)
.then(() => {
    app.listen(process.env.PORT || 5173, () =>{
        console.log("Server IS running "+"R");

    });
})

.catch(console.error);

 