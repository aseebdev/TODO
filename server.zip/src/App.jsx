
import { useEffect, useState } from "react";
import "./App.css";

const API = "http://localhost:5173/api";

async function request(path, options = {}) {
  const response = await fetch(API + path, {
    ...options,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "Something went wrong");
  }

  return data;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [register, setRegister] = useState(false);
  const [error, setError] = useState("");

  async function loadTasks() {
    setTasks(await request("/tasks"));
  }

  useEffect(() => {
    request("/me")
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  useEffect(() => {
    if (user) {
      loadTasks().catch((e) => setError(e.message));
    } else {
      setTasks([]);
    }
  }, [user]);

  async function submitAuth(e) {
    e.preventDefault();
    setError("");

    try {
      const result = await request(
        register ? "/register" : "/login",
        {
          method: "POST",
          body: JSON.stringify({ name, email, password }),
        }
      );
      setUser(result);
      setPassword("");
    } catch (e) {
      setError(e.message);
    }
  }

  async function addTask(e) {
    e.preventDefault();
    if (!title.trim()) return;

    try {
      const task = await request("/tasks", {
        method: "POST",
        body: JSON.stringify({ title }),
      });

      setTasks([task, ...tasks]);
      setTitle("");
    } catch (e) {
      setError(e.message);
    }
  }

  async function toggleTask(task) {
    try {
      const updated = await request(`/tasks/${task._id}`, {
        method: "PATCH",
        body: JSON.stringify({ completed: !task.completed }),
      });

      setTasks(tasks.map((t) =>
        t._id === updated._id ? updated : t
      ));
    } catch (e) {
      setError(e.message);
    }
  }

  async function deleteTask(id) {
    try {
      await request(`/tasks/${id}`, { method: "DELETE" });
      setTasks(tasks.filter((t) => t._id !== id));
    } catch (e) {
      setError(e.message);
    }
  }

  async function logout() {
    try {
      await request("/logout", { method: "POST" });
      setUser(null);
    } catch (e) {
      setError(e.message);
    }
  }

  if (!user) {
    return (
      <main className="auth">
        <h1>TaskFlow</h1>
        <p>Your day, organized.</p>

        <form onSubmit={submitAuth}>
          {register && (
            <input
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}

          <input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            placeholder="Password (8+ characters)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            minLength={8}
            required
          />

          <button>{register ? "Create account" : "Log in"}</button>
        </form>

        <p>{error}</p>

        <button className="link" onClick={() => {
          setRegister(!register);
          setError("");
        }}>
          {register ? "Already registered? Log in" :
            "New here? Create an account"}
        </button>
      </main>
    );
  }

  return (
    <main className="dashboard">
      <header>
        <div>
          <h1>TaskFlow</h1>
          <p>Hello, {user.name || user.email} 👋</p>
        </div>
        <button className="secondary" onClick={logout}>
          Log out
        </button>
      </header>

      <h2>My tasks</h2>

      <form className="add-form" onSubmit={addTask}>
        <input
          placeholder="What needs to be done?"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={200}
          required
        />
        <button>Add task</button>
      </form>

      <p>{error}</p>

      {tasks.length === 0 && <p>No tasks yet. Add your first one!</p>}

      {tasks.map((task) => (
        <div className="task" key={task._id}>
          <label>
            <input
              type="checkbox"
              checked={task.completed}
              onChange={() => toggleTask(task)}
            />
            <span className={task.completed ? "done" : ""}>
              {task.title}
            </span>
          </label>

          <button className="delete"
            onClick={() => deleteTask(task._id)}>
            Delete
          </button>
        </div>
      ))}
    </main>
  );
}
